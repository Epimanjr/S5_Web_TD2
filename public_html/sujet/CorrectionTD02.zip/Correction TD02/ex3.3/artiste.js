$(document).ready(function(){
  fadeImages();

  /**
   * Compute and display the age of the artist.
   */
  $("#ageButton").click(function () {
    // Birth date
    var birthYear = 1942;
    var birthMonth = 10; // 0 January, 1 February, etc.
    var birthDay = 27;

    var date = new Date();
    var currentYear = date.getFullYear();
    var currentMonth = date.getMonth();
    var currentDay = date.getDate();
  
    // Years
    var years = currentYear - birthYear;
  
    // Months
    var months = currentMonth - birthMonth;
    if (months < 0){
      years--;
  	  months = 12 + months;
    }
  
    // Days
    var days = currentDay - birthDay;
    if (days < 0){
      months--;
	  // Let's assume each month has 30 days
	  days = 30 + days;
    }
  
    // Seconds
    var seconds = date.getHours() * 3600 + date.getMinutes() * 60 + date.getSeconds();
  
    // write
    var container = $("#age");
    container.html(years + ' ans, ' + months + ' mois, ' + days + ' jours et ' + seconds + ' secondes.');
  });

  /**
   * Change the colours of the page and of the element with the id "colorChanger"
   */
  $("#colorChanger").click(function () {
    var container = $("#colorChanger");
    if (container.text() == "Orange"){
      $("body").css("background-color", "orange");
      container.css("background-color", "black");
      container.text("Black");
    }
    else{
      $("body").css("background-color", "black");
      container.css("background-color", "orange");
      container.text("Orange");
    }
  });

  /**
   * Randomly change the order of the "li" elements of the page.
   */
  $("#shuffleButton").click(function () {
    var playlist = $("#playlist");
    var list = playlist.children("li");
    var shuffled = shuffleArray(list);
    for (var i = 0; i < shuffled.length; i++){
      playlist.append(shuffled[i]);
    }
  });
});

/**
 * Taken from the Web. TODO: code my own some day...
 */
function shuffleArray(o){
    for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
    return o;
}

// variable to change the portrait pictures in the slide show
var portraitNumber = 0;

/**
 * Change the portrait of the artist every 5 seconds with a cross-fade effect.
 */
function fadeImages(){
    //remove previous image
	$("#portrait" + (portraitNumber - 1) % 4).remove();

	// Add new image to cross-fade
    var cyclerDiv = $("#cycler");
    cyclerDiv.append("<img id='portrait" + (portraitNumber + 1) % 4 + "' class='portrait' src='jimi" + (portraitNumber + 1) % 4 + ".jpg' />");
	
	// Cross-fade
	$("#portrait" + (portraitNumber + 1) % 4).hide().fadeIn(2000);
	$("#portrait" + portraitNumber).fadeOut(2000);

    // Next portrait    
	portraitNumber = (portraitNumber + 1) % 4;
	
	// Call back
	setTimeout(fadeImages, 5000);
}
