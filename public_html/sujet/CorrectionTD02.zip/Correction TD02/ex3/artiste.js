$(document).ready(function(){
	changeImage();
  
    /**
	 * Compute and display the age of the artist.
	 */
	$("#ageButton").click(function () {
	  // Birth date
	  var birthYear = 1942;
	  var birthMonth = 10; // 0 January, 1 February, etc.
	  var birthDay = 27;

	  var date = new Date();
	  var currentYear = date.getFullYear();
	  var currentMonth = date.getMonth();
	  var currentDay = date.getDate();
	  
	  // Years
	  var years = currentYear - birthYear;
	  
	  // Months
	  var months = currentMonth - birthMonth;
	  if (months < 0){
		years--;
		months = 12 + months;
	  }
	  
	  // Days
	  var days = currentDay - birthDay;
	  if (days < 0){
		months--;
		// Let's assume each month has 30 days
		days = 30 + days;
	  }
	  
	  // Seconds
	  var seconds = date.getHours() * 3600 + date.getMinutes() * 60 + date.getSeconds();
	  
	  // write
	  var container = $("#age");
	  container.html(years + ' ans, ' + months + ' mois, ' + days + ' jours et ' + seconds + ' secondes.');
	});

	/**
	 * Change the colours of the page and of the element with the id "colorChanger"
	 */
	$("#colorChanger").click(function () {
	  var container = $("#colorChanger");
	  if (container.text() == "Orange"){
		$("body").css("background-color", "orange");
		container.css("background-color", "black");
		container.text("Black");
	  }
	  else{
		$("body").css("background-color", "black");
		container.css("background-color", "orange");
		container.text("Orange");
	  }
	});

	/**
	 * Randomly change the order of the "li" elements of the page.
	 */
	$("#shuffleButton").click(function () {
	  var playlist = $("#playlist");
	  var list = playlist.children("li");
	  var shuffled = shuffleArray(list);
	  for (var i = 0; i < shuffled.length; i++){
		playlist.append(shuffled[i]);
	  }
	});
});

/**
 * Taken from the Web. TODO: code my own some day...
 */
function shuffleArray(o){
    for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
    return o;
}

/**
 * Change the artist portrait every 5 seconds.
 */
function changeImage(){
    setInterval(function(){
        if($("#image").attr("src")=="jimi.jpg"){
            $("#image").attr("src", "jimi2.jpg");
        }
        else if($("#image").attr("src")=="jimi2.jpg"){
            $("#image").attr("src", "jimi3.jpg");
        }
        else if($("#image").attr("src")=="jimi3.jpg"){
            $("#image").attr("src", "jimi4.jpg");
        }
        else if($("#image").attr("src")=="jimi4.jpg"){
            $("#image").attr("src", "jimi.jpg");
        }
    }, 5000);
}