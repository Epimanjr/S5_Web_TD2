function verification(){
  // une variable pour chaque boîte d'erreur
  var erreurIdentifiant = document.getElementById("erreurIdentifiant");
  var erreurMDP = document.getElementById("erreurMDP");
  var erreurMDP2 = document.getElementById("erreurMDP2");
  // etc.
  
  // nom d'utilisateur
  if (nouvelIdentifiant.value.length < 4){
    // Créer et afficher message d'erreur
	erreurIdentifiant.innerHTML = "<br/>Votre nom est trop court.";
  }
  else{
    // supprimer le message d'erreur
    var child = erreurIdentifiant.childNodes[0];
    erreurIdentifiant.removeChild(child);    
  }
  
  // Taille du mot de passe
  if (nouveauMDP.value.length < 8){
    // Créer et afficher message d'erreur
	erreurMDP.innerHTML = "<br/>Votre mot de passe est trop court.";
  }
  else{
    // supprimer le message d'erreur
    var child = erreurMDP.childNodes[0];
    erreurMDP.removeChild(child);    
  }
  
  // Mots de passe pas identiques
  if (nouveauMDP.value != nouveauMDP2.value){
    // Créer et afficher message d'erreur
	erreurMDP2.innerHTML = "<br/>Les mots de passe ne sont pas identiques.";
  }
  else{
    // supprimer le message d'erreur
    var child = erreurMDP2.childNodes[0];
    erreurMDP2.removeChild(child);    
  }
  
  // etc.
  
}