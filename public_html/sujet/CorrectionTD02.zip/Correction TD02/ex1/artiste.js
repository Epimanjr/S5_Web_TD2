function age(){
  // Birth date
  var birthYear = 1942;
  var birthMonth = 10; // 0 January, 1 February, etc.
  var birthDay = 27;

  var date = new Date();
  var currentYear = date.getFullYear();
  var currentMonth = date.getMonth();
  var currentDay = date.getDate();
  
  // Years
  var years = currentYear - birthYear;
  
  // Months
  var months = currentMonth - birthMonth;
  if (months < 0){
    years--;
	months = 12 + months;
  }
  
  // Days
  var days = currentDay - birthDay;
  if (days < 0){
    months--;
	// Let's assume each month has 30 days
	days = 30 + days;
  }
  
  // Seconds
  var seconds = date.getHours() * 3600 + date.getMinutes() * 60 + date.getSeconds();
  
  // write
  var container = document.getElementById("age");
  container.innerHTML = years + ' ans, ' + months + ' mois, ' + days + ' jours et ' + seconds + ' secondes.';
}

/**
 * Change the colours of the page and of the element with the id "colorChanger"
 */
function changeColors(){
  var container = document.getElementById("colorChanger");
  
  if (container.innerHTML == "Orange"){
    document.body.style.backgroundColor = "orange";
    container.style.backgroundColor = "black";
    container.innerHTML = "Black";
  }
  else{
    document.body.style.backgroundColor = "black";
    container.style.backgroundColor = "orange";
    container.innerHTML = "Orange";  
  }
}

/**
 * Randomly change the order of the "li" elements of the page.
 */
function shuffle(){
  var playlist = document.getElementById("playlist");
  var list = playlist.getElementsByTagName("li");
  var shuffled = shuffleArray(list);
  for (var i = 0; i < shuffled.length; i++){
    playlist.appendChild(shuffled[i]);
  }
}

/**
 * Taken from the Web. TODO: code my own some day...
 */
function shuffleArray(o){
    for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
    return o;
}